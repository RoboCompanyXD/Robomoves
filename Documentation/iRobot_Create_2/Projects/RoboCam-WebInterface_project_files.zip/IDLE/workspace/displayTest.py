import create2control


display_string = 'asdf'

noError = True
display_list = []
 
if len(display_string) == 4:
    display_list = list(display_string)
else:
    #Too many or too few characters!
    noError = False
    print 'wrong char leng'
    #raise ROIDataByteError("Invalid ASCII input (Must be EXACTLY four characters)")
if noError:
    #SCI.send(configData['opcodes']['start'], tuple[display_list])
    out = tuple(display_list)
    print out
else:
    #raise ROIFailedToSendError("Invalid data, failed to send")
    print 'error'
